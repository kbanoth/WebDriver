///**
// * 
// */
//package com.selenium.webdriver;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
///**
// * @author satya
// *
// */
//public class Webdriverbasic {
//
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
//		WebDriver driverr=new ChromeDriver();
//		
//	}
//}
